# Espelho de Ponto – versão Cloudflare (Pages + D1)

Mesmo sistema da versão Netlify, rodando de graça na Cloudflare (sem pausar por créditos).

## Estrutura
- `public/` – o site (index.html) e `_headers` (segurança)
- `functions/api/[[path]].js` – a API (login, permissões, dados)
- `schema.sql` – tabela do banco D1
- `gerar-senha.mjs` – gera hash de senha para o administrador

## Passo a passo
1. **GitHub**: crie um repositório novo (ex.: `espelho-ponto`) e envie o conteúdo desta pasta (as pastas `public` e `functions` e os arquivos soltos). Não coloque senhas no repositório.
2. **Banco D1**: Cloudflare → Storage & Databases → D1 → Create → nome `espelho-db`. Abra o **Console** do banco, cole o conteúdo de `schema.sql` e execute.
3. **Pages**: Workers & Pages → Create → Pages → Connect to Git → escolha o repositório. Framework preset: *None*. Build command: vazio. Build output directory: `public`. Production branch: `main`. Salve e faça o deploy.
   - Importante: o projeto precisa ser conectado ao Git (upload direto de arquivos não roda a API).
4. **Binding do banco**: projeto → Settings → Bindings → Add → D1 database → Variable name `DB` → selecione `espelho-db`.
5. **Variáveis (Secrets)**: Settings → Variables and Secrets → adicione como *Secret*:
   - `SESSION_SECRET` = texto aleatório com 32+ caracteres
   - `AUTH_USERS` = `{ "diogo machado": "<hash gerado>" }` (use `node gerar-senha.mjs "diogo machado" "SuaSenha"`)
6. **Redeploy**: Deployments → ⋯ no último deploy → Retry deployment (as variáveis só valem após novo deploy).
7. Acesse `https://NOME-DO-PROJETO.pages.dev` (use o endereço principal; o endereço com código hash demora uns minutos para o certificado SSL).

## Observações
- Os dados do Netlify **não são migrados**: importe de novo o arquivo do relógio de ponto e recrie os acessos de funcionários.
- Senhas usam PBKDF2 com 100.000 iterações (limite da Cloudflare). Hashes gerados pela versão Netlify (210.000) não funcionam: gere novos com `gerar-senha.mjs`.
- Se o login der "Error 1102" (limite de CPU do plano grátis), avise: dá para reduzir as iterações.
- Limites grátis: 100 mil requisições/dia, banco de 5 GB — muito acima do uso desta equipe.
